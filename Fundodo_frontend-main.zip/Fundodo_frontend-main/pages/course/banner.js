import Image from 'next/image';
import scss from './banner.module.scss';
import dog from "@/public/homepagePic/whitedog.png"

export default function Banner() {
  return (
    <>
    <div className='container'>
      <div className={scss.banner}>
        
      </div>
    
      </div>
    </>
  );
}
