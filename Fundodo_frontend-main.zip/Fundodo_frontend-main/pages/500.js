export default function Custom500() {
  return <h1>500 - Server-side error occurred</h1>
}
